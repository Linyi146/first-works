const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const app = express();
const session = require('express-session');
require('./db/db');
app.set('view engine', 'ejs');
// 静态托管
app.use(express.static('public'));
app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(bodyParser.json());
app.use(session({
    secret: 'qwqwqwq',
    resave: false,
    saveUninitialized: true,
    cookie: {
        maxAge: 24 * 60 * 60 * 1000
    },
    rolling: true
}));
// 不是登录页面及登录操作时,重定向到登录页面
app.use((req, res, next) => {
    if (req.url != '/admin/login' && req.url != '/admin/conlogin' && !req.session.username) {
        res.redirect('/admin/login');
    } else {
        next();
    }
});
app.use('/admin', require('./routes/admin.js'));
app.listen(3000, () => {
    console.log('3000端口开启了');
});