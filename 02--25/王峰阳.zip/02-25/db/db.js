// 1.引入mongoose模块
const mongoose = require('mongoose');
// 连接数据库dscsysdb
let DB = mongoose.connect('mongodb://localhost/linyi', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('连接数据库成功');
}, () => {
    console.log('连接数据库失败');
});