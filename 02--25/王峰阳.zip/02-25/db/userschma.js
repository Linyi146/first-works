const mongoose = require('mongoose');
const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: [true, '用户名不能为空'],
        minlength: [6, '用户名不能小于6位'],
        maxlength: [12, '用户名不能大于12位'],
        trim: true
    },
    password: {
        type: String,
        required: true,
        trim: true
    },
    age: {
        type: Number,
        min: [18, '年龄不能小于18'],
        max: [100, '年龄不能大于100']
    },
    sex: {
        type: String,
        enum: {
            values: ['男', '女', '保密'],
            message: '性别信息,如果请到专业机构确认'
        }
    },
    address: {
        type: String
    },
    createtime: {
        type: Date,
        default: Date.now
    }
});
const User = mongoose.model('nta', userSchema);
module.exports = User