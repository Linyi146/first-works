// 跳转到添加用户的页面
module.exports = (req, res) => {
    res.render('./admin/adduser.ejs');
}