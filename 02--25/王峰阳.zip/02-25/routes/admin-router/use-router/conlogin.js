const User = require('../../../db/userschma');
const md5 = require('md5');
module.exports = async(req, res) => {
    console.log(req.body);
    // 获取用户名和密码跟数据库作比对
    let usernamerel = await User.findOne({ "username": req.body.username });
    console.log(usernamerel);
    let userInfo = {
        username: req.body.username,
        password: md5(req.body.password)
    };
    // 用户名验证
    if (!usernamerel) {
        res.send('<script>alert("用户名不存在");location.href="/admin/login";</script>');
    } else {
        let loginrel = await User.findOne(userInfo);
        if (loginrel) {
            req.session.username = req.body.username;
            res.redirect('/admin/userlist');
        } else {
            res.send('<script>alert("密码错误");location.href="/admin/login";</script>');
        }
    }
}