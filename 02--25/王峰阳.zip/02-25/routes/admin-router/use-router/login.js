// 登录的请求ejs
module.exports = (req, res) => {
    res.render('./admin/login.ejs');
}