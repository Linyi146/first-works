let fs=require('fs')
// 异步操作
// 读取文件
fs.readFile('../02-node-练习/01.txt','utf8',(err,data)=>{//url,读取文本格式,回调函数
if(err){
    console.log(err);
}else{
    console.log(data);
}
})
// 写入文件
fs.writeFile('./02.txt','我是谁?',(err)=>{//三个参数值:url,写入内容,回调函数
    if(err){
        console.log(err);
    }else{
        console.log('data');
    }
})
// 追加数据
fs.appendFile('./01.txt','我是刘佳星',(err)=>{//url,追加内容,回调函数
    if(err){
        console.log(err);
    }else{
        console.log('追加成功');
    }
})
// 删除文件
// fs.unlink('./02.txt',(err)=>{//两个参数:url,回调函数
//     if(err){
//         console.log(err);
//     }else{
//         console.log('删除成功');
//     }
// })
// 重命名文件
fs.rename('./01.txt','001.txt',(err)=>{//目标文件名称,新文件名称,回调函数
    if(err){
        console.log(err);
    }else{
        console.log('重命名成功');
    }
})