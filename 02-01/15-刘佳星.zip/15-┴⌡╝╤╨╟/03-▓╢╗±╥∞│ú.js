const { error } = require('console');
let fs = require('fs');
// 同步执行
// let datas=fs.readFileSync('./02.txt','utf8');
// console.log(datas);
// 捕获异常
try{
    let datas=fs.readFileSync('./02.txt','utf8');
    console.log(datas);
}catch(error){
console.log(error);
}