
let fs = require('fs');
// 第一种:Promise
let read = function (url) {
    return new Promise((resolve, reject) => {
        fs.readFile(url, 'utf8', (err, data) => {
            if (err) {
                reject(err)
            } else {
                resolve(data)
                console.log(data);
            }
        })
    })
}
// 重命名文件
let rename = function (old, news) {
    return new Promise((resolve, reject) => {
        fs.rename(old, news, (err) => {
            if (err) {
                reject(err)
            } else {
                resolve('重命名成功')
            }
        })
    })
}
// read('./02.txt')
read('./002.txt').then((data) => {
    console.log(data);
    return read('./001.txt')
}).then((data) => {
    console.log(data);
    return rename('./02.txt', './002.txt')
}).then((data) => {
    console.log(data);
})
// 第二种方法:
