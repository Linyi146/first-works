let fs=require('fs');
let read = function (url) {
    return new Promise((resolve, reject) => {
        fs.readFile(url, 'utf8', (err, data) => {
            if (err) {
                reject(err)
            } else {
                resolve(data)
            }
        })
    })
}
// 重命名文件
let rename = function (old, news) {
    return new Promise((resolve, reject) => {
        fs.rename(old, news, (err) => {
            if (err) {
                reject(err)
            } else {
                resolve('重命名成功')
            }
        })
    })
}


function* fun(){
yield read('./001.txt')
yield read('./002.txt')
yield rename('./002.txt','./02.txt')
}
// 调用:
// 重点:必须定义一个变量来接收这个变量,以确保下面return的结果不一样
let str=fun()
str.next().value.then((data)=>{
    console.log(data);
    return str.next().value;
}).then((data)=>{
    console.log(data);
    return str.next().value;
}).then((data)=>{
    console.log(data);
})
