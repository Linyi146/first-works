let fs=require('fs');
let read = function (url) {
    return new Promise((resolve, reject) => {
        fs.readFile(url, 'utf8', (err, data) => {
            if (err) {
                reject(err)
            } else {
                resolve(data)
            }
        })
    })
}
// 重命名文件
let rename = function (old, news) {
    return new Promise((resolve, reject) => {
        fs.rename(old, news, (err) => {
            if (err) {
                reject(err)
            } else {
                resolve('重命名成功')
            }
        })
    })
}
async function fun(){
    let a=await read('./001.txt')
    let b=await read('./02.txt')
    let c=await rename('./02.txt','./002.txt')
    console.log(a);
    console.log(b);
    console.log(c);
}
fun();