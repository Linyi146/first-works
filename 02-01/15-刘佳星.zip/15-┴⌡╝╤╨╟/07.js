let fs = require('fs');
// 判定是文档或者目录
fs.stat('../02-node-练习', (err, stats) => {
    if (err) {
        console.log(err);
    } else {
        if (stats.isDirectory()) {
            console.log('目录');
        } else {
            console.log('文件');
        }
    }
})
// 添加文件
fs.mkdir('../02-node-练习/css', (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('目录创建成功');
    }
})
// // 删除文件
fs.rmdir('../02-node-练习/css', (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('删除目录成功');
    }
})
// 读取文件夹
fs.readdir('../02-node-练习', (err,str) => {
    if (err) {
        console.log(err);
    } else {
        console.log(str);
        // console.log();
    }
})