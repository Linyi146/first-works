let fs = require('fs');
fs.mkdir('../02-node-练习',{
recursive:true
},(err)=>{
    if(err){
        console.log(err);
    }else{
        console.log('创建目录成功');
    }
})
fs.readdir('../02-node-练习',{withFileTypes:true},(err,files)=>{
    if(err){
        console.log(err);
    }else{
        console.log(files);
    }
})