let fs=require('fs')
let datas='16545163156';
let sss=fs.createWriteStream('./001.txt')
for(let i=0;i<500;i++){
    sss.write(datas);

}
// 写入结束
// sss.end()
// sss.on('finish',()=>{
//     console.log('成功');
// })