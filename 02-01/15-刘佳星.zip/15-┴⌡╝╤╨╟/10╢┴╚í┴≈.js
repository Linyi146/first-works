let fs=require('fs');
let ss=fs.createReadStream('./001.txt')
// 保存数据
let str='';
// data;用于读取数据
ss.on('data',(dataStr)=>{
    str+=dataStr
});
ss.on('end',()=>{
    console.log(str);
    // console.log();
})