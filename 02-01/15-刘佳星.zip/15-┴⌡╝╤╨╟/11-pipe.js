let fs = require('fs');
// 读取流
let aa=fs.createReadStream('./001.txt')
// 写入流
let ss=fs.createWriteStream('./002.txt')
// 读取流的方法pipe()
aa.pipe(ss)
// 读取完成
aa.on('end',()=>{
    console.log('读取完成');
})