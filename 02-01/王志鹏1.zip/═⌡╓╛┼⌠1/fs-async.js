let fs = require('fs')

function read(fileP) {
    return new Promise((resolve) => {
        fs.readFile(fileP, 'utf8', (err, data) => {
            resolve(data);
        })
    })
};
async function readf() {
    let file1 = await read('./files/01.txt');
    let file2 = await read('./files/02.txt');
    let file3 = await read('./files/03.txt');
    console.log(file1);
    console.log(file2);
    console.log(file3);
}
readf();