let fs = require('fs');
//判断是文件夹还是文件
// stats.isDirectory() 判断是否是目录
// stats.isFile() //判断是否是文件
// fs.stat('./files/01.txt', (err, stats) => {
//     if (err) {
//         console.log(err);
//     } else {
//         if (stats.isDirectory()) {
//             console.log('是文件夹');
//         } else if (stats.isFile()) {
//             console.log('是文件');
//         }
//     }
// })
//创建文件夹
// fs.mkdir('./files/css', err => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('文件夹创建成功');
//     }
// })
// 删除空的文件夹，fs.rmdir只能删除空的文件夹
// fs.rmdir('./files/css', err => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('目录删除成功');
//     }
// })
// 读取文件夹
fs.readdir('./files', (err, files) => {
    if (err) {
        console.log(err);
    } else {
        console.log(files); //files是一个数组，数组里的元素是文件夹里包含的文件的名字，只能读取一层，如果文件夹里有文件夹和小文件，则只把内嵌的文件名加入到数组中
        console.log(files[2]);
    }
})