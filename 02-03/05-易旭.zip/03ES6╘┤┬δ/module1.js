 var firstName = '李白';
 var secondName = '青莲居士';
 // 私有变量
 var age = 22;

 function getAge() {
     return age;
 }

 function setAge() {
     age++;
 }

 function fun() {
     console.log('默认导出');
     return 'morning'
 }
 // 导出
 // export { firstName, secondName, getAge as getterAge, setAge as setterAge }
 // export 可以有多个
 //  - export default 则不需要加{}。
 export default fun;