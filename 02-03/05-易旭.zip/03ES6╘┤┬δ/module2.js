// 导入
// import { firstName, getAge } from './module1.js'

// - export default 向外暴露的成员，可以使用任意变量来接收。
import yy from './module1.js'
console.log(yy());