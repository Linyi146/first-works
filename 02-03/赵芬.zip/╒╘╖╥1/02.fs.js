// fs:file system
//读取文件,fs.readFile
// 写入文件fs.writeFile
// 追加文件fs.appendFile
// 删除文件fs.unlink
// 重命名文件fs.renameFile
//require:引入模块
let fs = require('fs');
// console.log(fs);
// 读取文件fs.readFile()
// . / 同级
// ../上级
fs.readFile('./files/01.txt', (err, data) => {
    if (err) {
        console.log(err);
    } else {
        console.log(data);
    }
})