let fs = require('fs');
// 1读取文件
// fs.readFile('./files/01.txt', 'utf8', (data, err) => {
//         if (data) {
//             console.log(data);
//         } else {
//             console.log(err);
//         }
//     })
// 2.写入文件
// fs.writeFile('./files/02.txt', '写入操作', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('写入成功');
//     }
// })
// 3.追加数据
// fs.appendFile('./files/03.txt', '追加', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('追加成功');
//     }
// })
//4.删除文件
// fs.unlink('./files/del.txt', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('删除成功');
//     }
// })
// 5.重命名操作
// fs.rename('./files/04.rename.txt', './files/06.name.txt', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('重命名成功');
//     }
// })
// 6.同步操作
// let data = fs.readFileSync('./files/01.txt', 'utf8');
// console.log(data);
// try {
//     let data = fs.readFileSync('./files/04.txt', 'utf8');
//     console.log(data);
// } catch {
//     console.log('异常');
// }