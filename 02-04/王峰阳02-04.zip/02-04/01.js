let http = require('http');
// console.log('http');
let server = http.createServer((req, res) => {
    res.writeHead(200, {
        'Content-Type': 'text/html;charset=UTF-8'
    });
    res.write('王峰阳');
    res.write('<p>p标签的汉字</p>');
    res.end();
});
server.listen(3000, () => {
    console.log('123456789');
})