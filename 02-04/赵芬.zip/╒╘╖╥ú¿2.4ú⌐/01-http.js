// 使用createServer()创建服务器
// request请求
// response：返回消息等内容
// 1.引入http模块
let http = require('http');
// console.log(http);
// 2.创建服务
let server = http.createServer((req, res) => {
        // 3.设置响应头
        res.writeHead(200, 'success', {
            'Content-Type': 'text/html;charset=utf-8'
        });
        // 4.写入页面的内容
        res.write('<div style="color:red">响应到页面的信息</div>');
        //5.结束请求
        res.end('ok');
    })
    // 6.设置监听
server.listen(3000, () => {
    console.log('running：3000');
})