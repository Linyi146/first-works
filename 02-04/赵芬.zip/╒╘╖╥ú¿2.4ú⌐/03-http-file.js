// 1.引入模块
let http = require('http');
// console.log(http);
let fs = require('fs');
// console.log(fs);
// 2.创建服务器
let server = http.createServer((req, res) => {
    console.log(server);
    console.log(req.url);
    // 3.写响应头
    res.writeHead(200, {
        'Content-Type': 'text/html;charset=utf-8'
    });
    //4.读取文件内容设置到页面
    //路径
    if (req.url != './favicon.ico') {
        let filePath = './files' + req.url;
        console.log(filePath);
        fs.readFile(filePath, (err, data) => {
            if (err) {
                console.log(err);
            } else {
                res.write(data)
            }
            // 5.结束
            res.end('ok');
        })
    }

});
// 6. 监听端口号
server.listen(3000, () => {
    console.log('ctrl+c退出');
})