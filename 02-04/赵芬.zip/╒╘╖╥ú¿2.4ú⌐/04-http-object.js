// 1. 引入模块
let http = require('http');
// 2.创建服务器
let server = http.createServer((req, res) => {
    // 3.写响应头
    res.writeHead(200, 'success', {
        'Content-Type': 'text/html;charset=utf-8'
    });
    // http://localhost:3000/login?uname=zhangmeili&password=666
    let fileURL = req.url;
    if (req.url != 'favicon.icon') {
        if (fileURL.includes('?')) {
            var obj = {};
            var arr = fileURL.split('?')[1].split('&');
            console.log(arr);
            arr.forEach((value) => {
                var tempArr = value.split('=');
                obj[tempArr[0]] = tempArr[1];
            });
            console.log(obj);
            res.end('ok');
        } else {
            console.log('无数据');
        }
    }
});
server.listen(3000, () => {
    console.log('running:3000');
})