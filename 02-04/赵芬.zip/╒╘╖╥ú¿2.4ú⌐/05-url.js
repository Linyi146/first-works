let url = new URL('http://www.hg-zn.com:3000/login?uname=zhangmeili&password=666#888888');
// console.log(url);
// 完整的URL
// href: 'http://www.hg-zn.com:3000/login?uname=zhangmeili&password=666#888888',
// 域
//     origin: 'http://www.hg-zn.com:3000',
// 协议
//     protocol: 'http:',
// 用户名
//     username: '',
// 密码
//     password: '',
// 主机名和端口号
//     host: 'www.hg-zn.com:3000',
// 主机名
//     hostname: 'www.hg-zn.com',
// 端口号
//     port: '3000',
// 路径名
//     pathname: '/login',
// 问号后面部分
//     search: '?uname=zhangmeili&password=666',
//     searchParams: URLSearchParams { 'uname' => 'zhangmeili', 'password' => '666' },
//     hash: '#888888'
// 声明请求url参数
let searchpar = url.searchParams;
// console.log(searchpar);
// // 解构
// for (let [key, value] of searchpar) {
//     console.log(key);
//     console.log(value);
// }
// // forEach遍历
// searchpar.forEach((value, key) => {
//         console.log(key);
//         console.log(value);
//     })
//     //entries
// for (let [key, value] of searchpar.entries()) {
//     console.log(key);
//     console.log(value);
// }
// // keys()
// for (let keys of searchpar.keys()) {
//     console.log(keys);
// }
// 方法
searchpar.append('gender', 'nv');
// searchpar.delete('password');
// console.log(searchpar);
// console.log(searchpar.entries());
// console.log(searchpar.get('gender'));
// console.log(searchpar.getAll('gender')); //返回数组
// console.log(searchpar.has('gender'));
// console.log(searchpar.has('gendesr'));
// console.log(searchpar.keys());
searchpar.append('key', '111');
searchpar.append('key', '222');
searchpar.append('key', '333');
// console.log(searchpar);
// console.log(searchpar.keys());
// console.log(searchpar.get('key'));
// console.log(searchpar.getAll('key'));