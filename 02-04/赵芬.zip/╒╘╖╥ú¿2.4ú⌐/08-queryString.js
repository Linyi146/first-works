const http = require('http');
const queryStr = require('querystring');
let server = http.createServer((req, res) => {
    res.writeHead(200, {
        'Content-Type': 'text/html;charset=utf-8'
    });
    // http://localhost:3000/login?uname=zhangmeili&password=666
    console.log(req.url);
    let reqURL = req.url;
    if (reqURL != '/favicon.icon') {
        if (reqURL.includes('?')) {
            var reqstr = reqURL.split('?')[1];
            console.log(reqstr);
            console.log(queryStr.parse(reqstr));
            res.end('ok');
        } else {
            res.end('无参数存储');
        }
    }
});
server.listen(3000, () => {
    console.log('1111');
})