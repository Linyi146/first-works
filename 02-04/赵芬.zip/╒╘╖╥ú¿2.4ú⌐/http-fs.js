const http = require('http');
const fs = require('fs')
let server = http.createServer((req, res) => {
    res.writeHead(200, 'success', {
        'content-Type': 'text/html;charset=utf-8'
    });
    var filePath = './files' + req.url;
    console.log(filePath);
    fs.readFile(filePath, (err, data) => {
        if (err) {
            console.log(err);
        } else {
            res.write(data);
        }
        res.end('ok拉')
    })
})
server.listen(3000, () => {
    console.log('running');
})