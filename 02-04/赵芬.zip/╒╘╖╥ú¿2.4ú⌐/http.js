let http = require('http');
let server = http.createServer((req, res) => {
    res.writeHead(200, {
        'content-type': 'text/html;charset=utf-8'
    })
    res.write('赵芬');
    res.write('<div style="color: red;">111111</div>');
    res.end()
})
server.listen(3000, () => {
    console.log('按Ctrl+c退出');
})