// 被执行文件的绝对路径
// 当前模块的目录名。
console.log(__dirname);
// 当前执行文件的文件名
console.log(__filename);