const lodash = require('lodash');
const md5 = require('md5-node');
// const momoko = require('momoko');
const momoko = require('momoko.js');

// 第三方模块可以从node_module文件夹中进行加载
console.log(momoko);