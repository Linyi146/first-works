{
    // 项目名
    "name": "huaproject",
    // 版本号
    "version": "1.0.0",
    // 项目的描述
    "description": "test init",
    // 项目的入口文件
    "main": "index.js",
    // 启动项目的测试代码
    "scripts": {
        "test": "echo \"Error: no test specified\" && exit 1"
    },
    // 关键词
    "keywords": [
        "init"
    ],
    // 作者
    "author": "momoko",
    // 项目发型时需要的证书
    "license": "ISC"
}