// 引入expres
// const express = require('express');
const app = require('express')();
app.get("/", (req, res) => {
    res.send('hello  王峰阳');
});
app.listen(3000, () => {
    console.log('已经打开服务器');
})