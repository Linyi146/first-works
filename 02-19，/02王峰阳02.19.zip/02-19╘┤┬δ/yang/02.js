const { nextTick } = require('process');

// 引入
const app = require('express')();
// req请求  res响应
app.get("/", (req, res) => {
    res.send('你好，王峰阳');
});
// 来个中间件
app.get('/wang', (req, res, next) => {
    console.log(req.query.name);
    req.name = '永远的神';
    next();
});
app.get('/wang', (req, res) => {
    res.send(req.name)
});
app.listen(3000)