const express = require('express');
const app = express();
app.get("/wang3", (req, res, next) => {
    // console.log(req.query.name);
    req.name = '王峰阳3';
    next();
});
app.get('/wang3', (req, res) => {
    res.send(200, req.name);
});
app.listen(3000)