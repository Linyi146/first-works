// 引入express
const app = require('express')();
app.use((req, res, next) => {
    console.log(req.url);
    if (req.url == '/wang4') {
        next();
    } else {
        res.status(404).send('错误');
    }
});
app.use('/wang4', (req, res) => {
    res.send('资源找到');
});
app.listen(3000);