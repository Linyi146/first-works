// 引入express
const app = require('express')();
app.use((req, res, next) => {
    console.log(req.url);
    next();
});
app.get('/wang51', (req, res) => {
    console.log(req.query);
    res.status(200).send(req.query);
});
app.get('/wang52/:iiid', (req, res) => {
    console.log(req.params);
    console.log(req.query.iiid);
    res.status(200).send(req.params);
});
app.get('/wang53/:aaa/:bbb/:ccc', (req, res) => {
    console.log(req.params);
    res.status(200).send(req.params);
});
app.listen(3000);