const fs = require('fs')
const path = require('path');
let fileUrl = 'F:\\Test';

function shanchufun(url) {
    let files = [];
    if (fs.existsSync(url)) {
        files = fs.readdirSync(url);
        files.forEach(function(file) {
            const curPath = path.join(url, file);
            console.log(curPath);
            if (fs.statSync(curPath).isDirectory()) {
                shanchufun(curPath);

            } else {
                fs.unlinkSync(curPath);
            }
        });
        fs.rmdirSync(url);
    } else {
        console.log("给定的路径不存在，请给出正确的路径");
    }
};
shanchufun('./bbb')