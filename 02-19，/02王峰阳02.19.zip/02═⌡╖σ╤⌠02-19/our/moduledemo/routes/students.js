var express = require('express');
var router = express.Router();
var fs = require('fs');

// 查询数据
router.get('/getStudent', (req, res) => {
    fs.readFile(__dirname + './../data/students.json', 'utf-8', (err, data) => {
        if (err) {
            res.status(500).end();
            return console.log(err);
        };
        try {
            data = JSON.parse(data);
        } catch (e) {
            res.status(500).end();
            return console.log(e);
        };
        var results = []; //存储返回结果
        var myid = req.query.id;
        var myname = req.query.name;
        if (myid) {
            data.forEach(item => {
                if (item.id == myid) {
                    results.push(item);
                }
            })
        } else if (myname) {
            data.forEach(item => {
                if (item.name.includes(myname)) {
                    results.push(item);
                }
            });
        } else {
            results = data;
        }
        res.status(200).send(results)
    })
});

// 创建学生
router.post('/addStudent', function(req, res) {
    fs.readFile(__dirname + './../data/students.json', 'utf8', function(err, data) {
        try {
            data = JSON.parse(data);
        } catch (e) {
            res.status(500).end();
            return console.log(e);
        }
        req.body.id = Date.now();
        req.body.date = new Date().toLocaleDateString();
        data.push(req.body);
        fs.writeFile(__dirname + './../data/students.json', JSON.stringify(data, null, 4), function(err) {
            if (err) {
                res.status(500).end();
                return console.log(err);
            }
            res.status(200).send(data);
        });
    });
});

// 删除学生
router.get('/removeStudent', function(req, res) {
    fs.readFile(__dirname + './../data/students.json', 'utf8', function(err, data) {
        if (err) {
            res.status(500).end();
            return console.log(err);
        }
        try {
            data = JSON.parse(data);
        } catch (e) {
            res.status(500).end();
            return console.log(e);
        }
        var index = -1;
        var myid = req.query.id;
        data.forEach(function(item, i) {
            if (item.id == myid) {
                index = i;
            }
        });
        if (index >= 0) {
            data.splice(index, 1);
        }
        fs.writeFile(__dirname + './../data/students.json', JSON.stringify(data, null, 4), function(err) {
            if (err) {
                res.status(500).end();
                return console.log(err);
            }
            res.status(200).send(data);
        });
    });
});

// 修改学生
router.post('/updateStudent', function(req, res) {
    fs.readFile(__dirname + './../data/students.json', 'utf8', function(err, data) {
        if (err) {
            res.status(500).end();
            return console.log(err);
        }
        try {
            data = JSON.parse(data);
        } catch (e) {
            res.status(500).end();
            return console.log(e);
        }
        data.forEach(function(item, index) {
            if (item.id == req.body.id) {
                data[index] = req.body;
            }
        });
        fs.writeFile(__dirname + './../data/students.json', JSON.stringify(data, null, 4), function(err) {
            if (err) {
                res.status(500).end();
                return console.log(err);
            }
            res.status(200).send(data);
        });
    });
});

router.get('/jsonpdemo', function(req, res) {
    var data = '[{"name": "张三"},{"name": "李四"},{"name": "王美丽"}]';
    res.status(200).send(req.query.callback + '(' + data + ')');
});
// module.exports 提供了暴露接口的方法
module.exports = router;