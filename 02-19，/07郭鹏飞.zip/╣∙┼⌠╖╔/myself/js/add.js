var baseURL = 'http://localhost:3008';
var addForm = document.querySelector('#add_form');
var studInfo = document.querySelectorAll('.stud_info');
var gender = document.querySelectorAll('.gender');
var hobbies = document.querySelectorAll('.hobby');
var allStudInfo = {};
addForm.onsubmit = function(e) {
    for (var i = 0; i < studInfo.length; i++) {
        allStudInfo[studInfo[i].name] = studInfo[i].value; 
    };
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].checked) {
            allStudInfo.gender = gender[j].value;
            break; 
        };
    };
    var tempHobby = []; 
    for (var k = 0; k < hobbies.length; k++) {
        if (hobbies[k].checked) {
            tempHobby.push(hobbies[k].value);
        }
    };
    allStudInfo.hobby = tempHobby.join(); 
    postData(baseURL + '/api/student/addStudent', allStudInfo, function() { 
        location.href = '../index.html';
    });
    e.preventDefault();
}