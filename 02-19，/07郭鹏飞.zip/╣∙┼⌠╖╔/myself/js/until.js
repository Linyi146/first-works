function getData(url, data, fun) { 
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url + dataFormatObj(data));
    xhr.send(null);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        };
    }
}
function postData(url, data, fun) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.setRequestHeader('Content-Type', 'application/json');
    var dataJson = JSON.stringify(data);
    xhr.send(dataJson);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        };
    };
};
function dataFormatObj(obj) {
    if (!obj) {
        return '';
    };
    var arrtemp = [];
    for (var key in obj) {
        var value = obj[key].toString();
        arrtemp.push(key + '=' + value);
    };

    return '?' + arrtemp.join('&');
};