let fs = require('fs')
let path = require('path');
function splices(url) {
    let arr = [];
    if (fs.existsSync(url)) {
        arr = fs.readdirSync(url);
        arr.forEach(function(file) {
            let cpth = path.join(url, file);
            if (fs.statSync(cpth).isDirectory()) {
                splices(cpth);

            } else {
                fs.unlinkSync(cpth);
            }
        });
        fs.rmdirSync(url);
    } else {
        console.log("路径错误");
    }
};
splices('./测试')