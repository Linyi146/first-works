let express = require('express');
let app = express.Router();
let fs = require('fs');
app.get('/getStudent', (req, res) => {
    fs.readFile(__dirname + '/students.json', 'utf8', (err, data) => {
        if (err) {
            res.status(500).end();
        }
        try {
            data = JSON.parse(data)
        } catch (e) {
            res.status(500).end();
        }
        // 将要返回的结果
        var results = [];
        // 指定的id
        var myid = req.query.id;
        // 指定的name
        var myname = req.query.name;
        console.log(myid)
        console.log(myname)

        // 获取指定id的学生信息
        if (myid) {

            data.forEach(function (item, index) {
                if (item.id == myid) {
                    results.push(item);
                }
            });

        } else if (myname) {
            // 获取指定name的学生信息
            data.forEach(function (item, index) {
                if (item.name.includes(myname)) {
                    results.push(item);
                }
            });

        } else {
            // 获取所有学生
            results = data;
        }

        res.status(200).send(results);

    })
})
// 创建学生
app.post('/addStudent', function (req, res) {
    fs.readFile(__dirname + '/students.json', 'utf8', function (err, data) {
        try {
            data = JSON.parse(data);
        } catch (e) {
            res.status(500).end();
            return console.log(e);
        }

        // 将时间戳作为学生ID
        req.body.id = Date.now().toString();

        // 设置学生的创建时间
        req.body.date = new Date().toLocaleDateString();

        // 设置学生的修改时间
        // req.body.update = new Date().toLocaleDateString();

        // 将题型信息添加到数组中
        data.push(req.body);

        console.log(data);
        // 将数据写回到文件中
        fs.writeFile(__dirname + '/students.json', JSON.stringify(data, null, 4), function (err) {
            if (err) {
                res.status(500).end();
                return console.log(err);
            }

            res.status(200).send(data);
        });
    });
});

app.get('/jsonpdemo', function (req, res) {


    console.log('前台传递过来的方法名为：' + req.query.callback);


    var data = '[{"name": "张三"},{"name": "李四"},{"name": "王美丽"}]';

    console.log('接收到请求');

    res.status(200).send(req.query.callback + '(' + data + ')');
    // res.status(200).send(fun(data));

});
// module.exports 提供了暴露接口的方法
module.exports = app;
