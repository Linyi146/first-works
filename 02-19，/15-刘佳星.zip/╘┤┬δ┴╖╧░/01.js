// express框架引入
let express=require('express');
// 生成express服务器
let app=express();
// req:请求
// res:响应
// app.get("/",(req,res)=>{
//     res.send('成功')
// })
// 请求体
app.use((req,res,next)=>{
    console.log(req.params);
    req.name = '张美丽';
    console.log(req.name);
    if(req.url=='/add'){
        next();
    }else{
        // res.send(200,'wancheng')
        res.status(200).send('成功111')
    }
    // res.status(200).send()=res.send(200,)
})
app.get('/add',(req,res)=>{
    res.send(200,req.name)
})
app.listen(3000,()=>{
    console.log('3000');
})
