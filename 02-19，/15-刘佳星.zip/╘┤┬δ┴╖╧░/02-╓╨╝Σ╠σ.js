let express = require('express');
// 生成express服务器
let app = express();
// app.use((req,res)=>{
//     res.send('chenggong')
// })
app.use((req, res, next) => {
    if (req.url == '/add') {
        next()
    } else {
        res.send(200,'putong')
    }
})
app.use('/add',(req,res)=>{
    res.send(200,'111')
})
app.listen(3000, () => {
    console.log('3000');
})