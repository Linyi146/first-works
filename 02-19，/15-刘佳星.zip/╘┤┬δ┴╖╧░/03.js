// let express = require('express');
// // 生成express服务器
// let app = express();

// // req.url为端口韩后面的值
// app.use((req,res,next)=>{
//     console.log(req.url);
//     next();
// })
// // query是get得到的参数
// // res.query是以参数形式传入的形式形成的对象 http://localhost:3000/login?name=zhangmeili&age=18
// // req.params是按照固定形式传入的参数形成的对象{'id':'164'}
// app.get('/add',(req,res)=>{
//     console.log(req.query);
//     res.send(200,req.query)
// })
// // 路由参数:指按照固定的形式传入的形式
// app.get('/ssd/:id',(req,res)=>{
//     console.log(req.params);
//     console.log(req.params.id);
//     res.send(200,req.params)
// })

// app.get('/aadd/:id/aa/:name',(req,res)=>{
//     console.log(req.params);
//     res.send(200,req.params)
// })

// app.listen(3000, () => {
//     console.log('3000');
// })
let express=require('express');
let app=express();
app.use((req,res,next)=>{
    console.log(req.url);
    next()
})
app.get('/aaa',(req,res)=>{
    console.log(req.query);
    res.send(req.query)
})
app.get('/ss/:id/dd/:name',(req,res)=>{
    console.log(req.params);
    res.send(req.params)
})
app.listen(3000,()=>{
    console.log('3000');
})