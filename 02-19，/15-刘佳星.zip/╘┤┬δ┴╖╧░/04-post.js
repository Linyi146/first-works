const express = require('express');
const app = express();
// 引入post相关的框架
const bodyParser=require('body-parser')
// post必须设置静态资源
app.use(express.static(__dirname));
// extended:false:参数时键值对的数据为string或者array
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json())
// 跨域请求
app.use((req,res,next)=>{
    res.header('Access-Control-Allow-Origin','*')
    res.header('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS')
    res.header('Access-Control-Allow-headers','X-Requested-With')
    res.header('Access-Control-Allow-headers','Content-Type')
    res.header('Content-Type','application/json');
    next();
})
app.post('/post',(req,res)=>{
    console.log(req.body);
    res.send(200,req.body)
})
app.listen(3000,()=>{
    console.log('3000已开启');
})