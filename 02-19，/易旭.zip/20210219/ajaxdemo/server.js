// 引入express框架
const express = require('express');
// 引入第三方post参数包
const bodyParser = require('body-parser');
// 引入i/o系统
const fs = require('fs');
// 初始化express框架
let app = express();
// 初始化静态资源
app.use(express.static('public'));
// 设置post读取格式
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// 跨域请求
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Content-Type', 'application/json');
    next();
});
// 设置接口以及处理函数
// get获取数据
app.get('/api/student/getstudent', (req, res) => {
    fs.readFile('data/student.json', 'utf-8', (err, data) => {
        if (err) {
            console.log('读取文件出错' + err);
            res.status(500).send('服务器出错!');
        } else {
            data = JSON.parse(data);
            // 存放查找结果
            let result = [];
            // 判断传回id是否存在通过遍历查找符合的结果
            if (req.query.id) {
                console.log(1);
                data.forEach((value, index) => {
                    if (value.id == req.query.id) {
                        // 符合的加入结果
                        result.push(value);
                    }
                })
                // 判断传回name是否存在通过遍历查找符合的结果
            } else if (req.query.name) {
                console.log(2);
                data.forEach((value, index) => {
                    if (value.name == req.query.name) {
                        // 符合的加入结果
                        result.push(value);
                    }
                })
            } else {
                // 如果不符合都则查找全部
                result = data;
            }
            console.log(data);
            res.status(200).send(result);
        }
    })
})
//post添加数据
app.post("/api/student/addstudent", (req, res) => {
    // 读取文件获取数据
    fs.readFile('data/student.json', (err, data) => {
        if (err) {
            console.log('读取文件出错' + err);
            res.status(500).send('服务器出错!');
        } else {
            data = JSON.parse(data);
            // 存放传回数据
            let result = req.body;
            // 生成id并添加
            result.id = new Date().getTime();
            // 添加数据进文件数据
            data.push(result);
            // 写入文件
            fs.writeFileSync('data/student.json', JSON.stringify(data, null, 4));
            console.log(result);
            res.status(200).send(result)
        }
    })
})
// 监听3000端口
app.listen(3000, () => {
    console.log('3000端口启动!');
})