//第一步安装
//安装
// npm install express --save
// npm install ejs --save
// 引入fs
const express = require('express');
// 不引入也可以
const ejs = require('ejs');
const fs = require('fs');
// 实例化
const app = express();

// 引入body-parser模块
const bodyParser = require('body-parser');

// 拦截请求
app.use(bodyParser.urlencoded({ extended: false }));

//设置express设置模板引擎
app.set('view engine', 'ejs');
// 找到view里面的ejs文件默认也可以不写
// app.app('views', __dirname + 'views');
//请求数据
const mongoose = require('mongoose');
let DB = mongoose.connect('mongodb://localhost/momokodb', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('连接数据库成功');
}, () => {
    console.log('连接数据库失败');
});
const userSchema = new mongoose.Schema(
    {
        uname: String,
        age: Number,
        gender: String
    }
);
const User = mongoose.model('user', userSchema);
app.get('/', (req, res) => {
    fs.readFile('./data/students.json', 'utf-8', (err, data) => {
        //判断如果发生错误
        if (err) {
            res.status(500).end();
            console.log(err);
        } else {
            studentsObj = JSON.parse(data);
            // ejs.renderFile('./views/index.ejs', studentsObj, (err, str) => {
            //     if (err) {
            //         res.write(500, {
            //             'Content-Type': 'text/plain;charset="utf-8"'
            //         });
            //         res.end('500 - application ERROR');
            //     } else {
            //         res.writeHead(200, {
            //             'Content-Type': 'text/html;charset="utf-8"'
            //         });
            //         res.end(str);
            //     }
            // });
            User.find().then((result) => {
                console.log(result);
            })

            res.end("index", studentsObj);
        }
    });
});
// app.get('.login', (req, res) => {
//     //要的是传递对象的键值
//     res.render("login", { title: '登录' });
// });
// //登录后到登陆后的页面
// app.post('/submit', (req, res) => {
//     console.log(req.body);
//     res.render("mainPage", {
//         title: '登陆后的首页面',
//         uname: req.body.uname
//     });
// });
//鉴定端口
app.listen(3000, () => {
    console.log('3000端口开启');
})