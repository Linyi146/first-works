const fs = require('fs');
// 递归删除文件函数
function remF(dir) {
    // 获取文件夹内的文件
    let files = fs.readdirSync(dir);
    console.log(files);
    // 循环遍历数组判断是否为文件夹
    for (let i = 0; i < files.length; i++) {
        // 拼出文件路径
        let fileDir = dir + '/' + files[i];
        // 获取文件信息
        let rel = fs.statSync(fileDir);
        // 如果是文件则删除
        if (rel.isFile()) {
            fs.unlinkSync(fileDir)
        } else {
            // 否则递归继续检查
            remF(fileDir);
        }
    }
    // 删除空文件夹
    fs.rmdirSync(dir);
}
remF('test');