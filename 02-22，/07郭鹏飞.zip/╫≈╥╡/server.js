let express = require('express');
const fs = require('fs');
let ejs = require('ejs');
const app = express();
let mongoose = require('mongoose');
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));

let DB = mongoose.connect('mongodb://localhost/User', { useNewUrlParser: true, useUnifiedTopology: true });

DB.then(() => {
    console.log('连接成功');
}, () => {
    console.log('连接失败');
});

const userSchema = new mongoose.Schema(
    {
        uname: String,
        age: Number,
        gender: String,
        hobby: String,
        say: String
    }
);

const User = mongoose.model('users', userSchema);

const user = new User({
    uname: '回复术士',
    age: 23,
    gender: '男',
    hobby:'烧火棍',
    say:'我是陈冠希...'
});
user.save();

app.get('/', (req, res) => {
    fs.readFile('./data/students.json', 'utf8', (err, data) => {
        if (err) {
            res.status(500).end();
            console.log(err);
        } else {
            User.find().then((result) => {
                let studentsObj = result;
                res.render('index', { studentsObj: studentsObj });
            });
        }

    });
});
app.listen(3000, () => {
    console.log('3000开启');
})