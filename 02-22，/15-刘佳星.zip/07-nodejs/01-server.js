let express=require('express')
let app = express();
// 跨域
let cors = require('cors');
app.use(cors());
// 引入两个模块
require('./db/01-db')
let home = require('./db/03.js')

app.get('/api/student/getStudent', (req, res) => {
    home.find().then((data) => {
        res.status(200).send('888')

    })
})
app.listen(3008, () => {
    console.log('3000开启');
})