let mongoose=require('mongoose');
let DB=mongoose.connect('mongodb://localhost/local',{ useNewUrlParser: true,useUnifiedTopology: true });
DB.then(()=>{
    console.log('链接成功');
},()=>{
console.log('链接失败');
})