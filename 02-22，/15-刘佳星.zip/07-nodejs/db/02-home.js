let express=require('express');
let router=express.Router();
router.get('/',(req,res)=>{
    res.send(200,'主页面')
})
module.exports=router