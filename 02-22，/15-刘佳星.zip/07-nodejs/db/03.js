const mongoose = require('mongoose');
const userSchema = new mongoose.Schema(
    {
        uname:String,
        age:Number,
        gender:String
    }
);
const User =mongoose.model('user',userSchema);
module.exports=User