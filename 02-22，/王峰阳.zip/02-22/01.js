const ejs = require('ejs');
var data = {
    name: "王峰阳",
};
var str = `<p>Hello <%= name %> </p>`;
var htmls = ejs.render(str, data);
console.log(htmls);