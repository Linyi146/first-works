const ejs = require('ejs');
var data = {
    name: "王峰阳"
};
let str = `
<p>Hello <%- name %></p>
<p>Hello <%= name %></p>`;
let htmls = ejs.render(str, data);
console.log(htmls);