const ejs = require('ejs');
let template = `
<div>
    <%# 导航头部 %>
    <nav>导航部分</nav>
</div>
<div>
    <%# 主题部分 -%>
    <nav>主题部分</nav>
</div>
`;
// <%#  注释内容 不输出到页面
// -%>  删除紧随其后的换行符
let htmls = ejs.render(template);
console.log(htmls);