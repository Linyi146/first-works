// 利用循环顺序添加数据
const ejs = require('ejs');
let dataObj = ['王', '峰', '阳'];
let template = `
    <% laObj.forEach(value=>{ %>
        <h2><%= value %></h2>
    <% }); %>
`;
let htmls = ejs.render(template, {
    laObj: dataObj
});
console.log(htmls);