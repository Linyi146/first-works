// 引入模块
const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const mongoose = require('mongoose');
const app = express();

// 设置模板引擎
app.set('view engine', 'ejs');
// 拦截窗体格式
app.use(bodyParser.urlencoded({ extended: false }));
// 链接数据库
const DB = new mongoose.connect('mongodb://localhost/linyi', { useNewUrlParser: true, useUnifiedTopology: true });
// 数据库链接状态
DB.then(() => {
    console.log('数据库链接成功');
}, () => {
    console.log('数据库链接失败');
});

// 入库规则
const schema = new mongoose.Schema({
    uname: String,
    age: Number,
    sex: String
});
// 创建表名
const User = mongoose.model('users', schema);
// 查询数据
app.get('/', (req, res) => {
    User.find().then((data) => {
        res.render('index', {
            obj: data,
            title: '添加数据'
        });
    });
});

app.get('/add', (req, res) => {
    res.render('add', { title: '添加数据' });
});

// 添加数据到数据库
app.post('/adds', (req, res) => {
    const user = User(req.body);
    user.save();
    res.send('添加成功      <a href="/">查看已经保存的数据数据</a>');
});
// 删除数据
app.get('/shans', (req, res) => {
    User.deleteOne({ _id: num }).then(rel => console.log(rel));
    res.send('删除成功      <a href="/">查看已经保存的数据数据</a>');
});

app.listen(3000, () => {
    console.log('3000开始');
});