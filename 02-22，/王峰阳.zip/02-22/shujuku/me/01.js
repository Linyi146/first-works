// 填入模块
const mongoose = require('mongoose');
let DB = mongoose.connect('mongodb://localhost/linnyi', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('连接数据库成功');
}, () => {
    console.log("连接数据库失败");
})