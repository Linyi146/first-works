// 引入模块
const mongoose = require('mongoose');
let DB = mongoose.connect('mongodb://localhost/linyi', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('连接数据库成功');
}, () => {
    console.log("连接数据库失败");
});
// 创建集合
const linyiSchema = new mongoose.Schema({
    uname: String,
    age: Number,
    gender: String
});
const Nta = mongoose.model('nta', linyiSchema);
console.log(Nta);
// 往数据库插入数据
const nta1 = new Nta({
    uname: '王峰阳',
    age: 22,
    gender: '男'
});
const nta2 = new Nta({
    uname: '陈红霞',
    age: 22,
    gender: '女'
});
// 保存数据到集合
nta1.save();
nta2.save();