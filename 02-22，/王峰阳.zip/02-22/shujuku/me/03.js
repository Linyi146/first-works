// 引入模块
const mongoose = require('mongoose');
let DB = mongoose.connect('mongodb://localhost/linyi', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('连接数据库成功');
}, () => {
    console.log("连接数据库失败");
});
// 创建集合
const linyiSchema = new mongoose.Schema({
    uname: String,
    age: Number,
    gender: String
});
const Nta = mongoose.model('nta', linyiSchema);
// 查询结果
// Nta.find().then((result) => {
//     console.log(result);
// });
// 精确查找
Nta.find({ age: { $gt: 32 } }).then((reqult, res) => {
    console.log(reqult);
});