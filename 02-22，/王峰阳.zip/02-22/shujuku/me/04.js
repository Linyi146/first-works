// 引入模块
const mongoose = require('mongoose');
let DB = mongoose.connect('mongodb://localhost/linyi', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('连接数据库成功');
}, () => {
    console.log("连接数据库失败");
});
// 创建集合
const linyiSchema = new mongoose.Schema({
    uname: String,
    age: Number,
    gender: String
});
const Nta = mongoose.model('nta', linyiSchema);
// 修改
// Nta.updateMany({}, { uname: '王峰阳修改了' }).then((rel) => {
//     console.log(rel);
// });
// Nta.updateMany({ age: 22 }, { age: 222222 }).then((rel) => {
//     console.log(rel);
// });
// Nta.deleteMany({ age: 18 }).then(rel => console.log(rel));
// 添加
Nta.create({
    uname: "111王峰阳",
    age: 18,
    gender: "男"
}, {
    uname: "222王峰阳",
    age: 182,
    gender: "男"
})