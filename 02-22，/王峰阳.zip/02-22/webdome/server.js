const express = require('express');
// 不引入也可以
const ejs = require('ejs');
const fs = require('fs');
// 实例化
const app = express();


// 引入body-parser模块
const bodyParser = require('body-parser');
// 拦截请求
app.use(bodyParser.urlencoded({ extended: false }));


app.set('view engine', 'ejs');
app.get('/', (req, res) => {
    fs.readFile('./data/students.json', 'utf-8', (err, data) => {
        if (err) {
            res.status(500).end();
            console.log(err);
        } else {
            studentsObj = JSON.parse(data);
            // 读取ejs文件然后传递studentsObj给ejs,呈现html代码
            // ejs.renderFile('./views/index.ejs',studentsObj,(err,str)=>{
            //     if(err){
            //         res.writeHead(500,{
            //             'Content-Type':'text/plain;charset="utf-8"'
            //         });
            //         res.end('500 - application ERROR');
            //     }else{
            //         res.writeHead(200,{
            //             'Content-Type':'text/html;charset="utf-8"'
            //         });
            //         res.end(str);
            //     }
            // });
            // 要的是传递对象的键值
            res.render('index', studentsObj)
        };
    });
});

app.get('/login', (req, res) => {
    res.render('login', { title: '登录' })
});
app.post('/submit', (req, res) => {
    console.log(req.body);
    res.render("mainpage", {
        title: "登录后的界面",
        uname: req.body.uname,
        pwd: req.body.pwd
    })
})



app.listen(3000, () => {
    console.log('开始');
})