var tempArr = [];
for (var i = 0; i < 10; i++) {
    var num = Math.floor(Math.random() * 90) + 10;
    tempArr.push(num);
};
console.log(tempArr);
for (var i = 0; i < tempArr.length - 1; i++) {
    for (var j = 0; j < tempArr.length - i - 1; j++) {
        if (tempArr[j] > tempArr[j + 1]) {
            [tempArr[j], tempArr[j + 1]] = [tempArr[j + 1], tempArr[j]]
        }
    }
};
console.log(tempArr);