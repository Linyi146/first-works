const express = require('express');
const fs = require('fs');
// 实例化
const app = express();

// 引入body-parser模块
// const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const DB = mongoose.connect('mongodb://localhost/momokodb', { useNewUrlParser: true, useUnifiedTopology: true })
DB.then(() => {
    console.log('数据连接成功');
}, () => {
    console.log('数据连接失败');
});
const userSchema = new mongoose.Schema({
    uname: String,
    age: Number,
    gender: String
});
const User = mongoose.model('user', userSchema);
// 拦截请求
// app.use(bodyParser.urlencoded({ extended: false }));

// 设置express设置模板引擎
app.set('view engine', 'ejs');
// 找到views里面的ejs文件默认也可以不写
// app.set('views',__dirname+ '/views');
// 请求数据
app.get('/', (req, res) => {
    fs.readFile('./data/students.json', 'utf8', (err, data) => {
        // 判断如果读取发生错误
        // if (err) {
        //     res.status(500).end();
        //     console.log(err);
        // } else {
        User.find().then((result) => {
            console.log(result);
            res.render("index", { students: result })
        });
        // }
    });
});

// app.get('/login', (req, res) => {
//     // 要的是传递对象的键值
//     res.render("login", { title: '登录' });
// });
// // 登录后到登录后的首页面
// app.post('/submit', (req, res) => {
//     console.log(req.body);
//     res.render("mainPage", {
//         title: '登录后的首页面',
//         uname: req.body.uname
//     });

// });

// 监听端口
app.listen(3000, () => {
    console.log('3000开启啦啦啦啦啦啦啊');
});