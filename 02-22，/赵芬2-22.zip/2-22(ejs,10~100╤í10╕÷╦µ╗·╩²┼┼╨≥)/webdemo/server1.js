const express = require('express');
// const ejs = require('ejs');
const app = express();
app.set('view engine', 'ejs')
const mongoose = require('mongoose');
const DB = mongoose.connect('mongodb://localhost/momokodb', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('数据连接成功');
}, () => {
    console.log('数据连接失败');
});
const userSchema = new mongoose.Schema({
    uname: String,
    age: Number,
    gender: String
});
const User = mongoose.model('user', userSchema);
app.get('/', (req, res) => {
    User.find().then((result) => {
        console.log(result);
        res.render("index", { students: result })
    });
});
// 监听端口
app.listen(3000, () => {
    console.log('3000开启啦啦啦啦啦啦啊');
});