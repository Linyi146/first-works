var stuBody = document.querySelector('#tbody_stu');
var baseURL = 'http://localhost:3008';
getData(baseURL + '/api/student/getStudent', '', showPage);
function showPage(xhrObj) {
    console.log(0);
    var studentData = JSON.parse(xhrObj.responseText);
    var relDataHtml = ''; 
    for (var i = 0; i < studentData.length; i++) {
        relDataHtml += `<tr>
     <td>${studentData[i].id}</td>
     <td>${studentData[i].clazz}</td>
     <td>${studentData[i].name}</td>
     <td>${studentData[i].gender}</td>
     <td>${studentData[i].age}</td>
     <td>${studentData[i].tel}</td>
     <td>${studentData[i].hobby}</td>
     <td>${studentData[i].address}</td>
     <td>${studentData[i].remark}</td>
     <td>${studentData[i].date}</td>
     <td><a href="./page/update.html?id=${studentData[i].id}" class="update_btn" data-stud-id="${studentData[i].id}">修改</a><a href="JavasCRipt:void(0)" class="delete_btn" id="${studentData[i].id}">删除</a></td></tr>`
    };
    if (!relDataHtml) {
        relDataHtml = `<tr><td colspan="11">没有查询到数据</td></tr>`
    };
    stuBody.innerHTML = relDataHtml;
    addEvent();
};

function addEvent() {
    var deleteBtn = document.querySelectorAll('.delete_btn');
    for (var i = 0; i < deleteBtn.length; i++) {
        deleteBtn[i].onclick = function(e) {
            var flag = confirm('确定删除选定向?');
            if (flag) {
                getData(baseURL + '/api/student/removeStudent', { id: this.id }, function() { 
                    e.target.parentNode.parentNode.remove(); 
                });
            }
        }
    }
    var updateBtn = document.querySelectorAll('.update_btn');
    for (var k = 0; k < updateBtn.length; k++) {
        updateBtn[k].onclick = function() {
            localStorage.setItem('stuId', this.dataset.studId);
        }
    }
};
var searchValue = document.querySelector('#searchvalue');
var searchBtn = document.querySelector('#search_btn');
searchBtn.onclick = function() {
    var stuValue = searchValue.value.trim();
    getData(baseURL + '/api/student/getStudent', { name: stuValue }, showPage);
}