const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const router = express.Router();

require('../db/db.js');
let User = require('../db/dbuser.js');
function ajax(ajaxs) {
    User.find().then((data) => {
        ajaxs.send(200, data);
    });
};
router.get('/getStudent', (req, res) => {
    User.find(req.query).then((data) => {
        res.send(200, data);
    });
});
router.post('/addStudent', (req, res) => {
    req.body.id = Date.now().toString();
    if (!req.body.date) {
        req.body.date = new Date().toLocaleDateString();
        req.body.date = req.body.date.replace(/\//g, '-');
    };
    User.create(req.body).then((rel) => {
        console.log(rel);
        ajax(res);
    });
});
router.get('/removeStudent', (req, res) => {
    User.deleteOne(req.query).then((rel) => {
        console.log(rel);
        ajax(res);
    });
});
router.post('/updateStudent', (req, res) => {
    User.updateOne({
        id: req.body.id
    }, req.body).then((rel) => {
        console.log(rel);
        ajax(res);
    });
});
module.exports = router;