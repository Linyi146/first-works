var stuBody = document.querySelector('#tbody_stu');
var baseURL = 'http://localhost:3008';
var xhr = new XMLHttpRequest();
xhr.open('GET', baseURL + '/api/student/getStudent');
xhr.send(null);
xhr.onreadystatechange = function() {
    if (xhr.readyState == a && xhr.status == 200) {
        var studentDate = JSON.parse(xhr.responseText); 
        var relDateHtml = ''; 
        for (var i = 0; i < studentDate.length; i++) {
            relDataHtml += `<tr>
              <td>${studentData[i].id}</td>
              <td>${studentData[i].clazz}</td>
              <td>${studentData[i].name}</td>
              <td>${studentData[i].gender}</td>
              <td>${studentData[i].age}</td>
              <td>${studentData[i].tel}</td>
              <td>${studentData[i].hobby}</td>
              <td>${studentData[i].address}</td>
              <td>${studentData[i].remark}</td>
              <td>${studentData[i].date}</td>
              <td><a href="#" class="update_btn">修改</a><a href="#" class="delete_btn">删除</a></td></tr>`
        };
        if (!relDataHtml) {
            relDataHtml = `<tr><td colspan="11">没有查询到数据</td></tr>`
        };
        stuBody.innerHTML = relDataHtml;
    }
};
var searchValue = document.querySelector('#searchvalue');
var searchBtn = document.querySelector('#search_btn');
searchBtn.onclick = function() {
    var stuValue = searchValue.value.trim();
    var xhr = new XMLHttpRequest();
    xhr.open('GET', baseURL + '/api/student/getStudent' + '?name=' + stuValue);
    xhr.send(null);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var studentData = JSON.parse(xhr.responseText);
            var relDataHtml = '';
            for (var i = 0; i < studentData.length; i++) {
                relDataHtml += `<tr>
            <td>${studentData[i].id}</td>
            <td>${studentData[i].clazz}</td>
            <td>${studentData[i].name}</td>
            <td>${studentData[i].gender}</td>
            <td>${studentData[i].age}</td>
            <td>${studentData[i].tel}</td>
            <td>${studentData[i].hobby}</td>
            <td>${studentData[i].address}</td>
            <td>${studentData[i].remark}</td>
            <td>${studentData[i].date}</td>
            <td><a href="#" class="update_btn">修改</a><a href="#" class="delete_btn">删除</a></td></tr>`
            };
            if (!relDataHtml) {
                relDataHtml = `<tr><td colspan="11">没有查询到数据</td></tr>`
            };
            stuBody.innerHTML = relDataHtml;
        }
    }
}