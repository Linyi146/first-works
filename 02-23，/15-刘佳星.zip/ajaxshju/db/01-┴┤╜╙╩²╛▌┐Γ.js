let mongoose=require('mongoose');
let DB= mongoose.connect('mongodb://localhost/ajax', { useNewUrlParser: true, useUnifiedTopology: true })
DB.then(()=>{
    console.log('成功');
},()=>{
    console.log('失败');
})