let mongoose=require('mongoose');
let mongooseSchema=mongoose.Schema({
    name:String,
    age:Number,
    gender:String,
    hobby:String
})
let userdata=mongoose.model('user',mongooseSchema)
module.exports=userdata