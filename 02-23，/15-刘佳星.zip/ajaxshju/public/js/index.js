// 获取元素
var stuBody = document.querySelector('#tbody_stu');
// 服务器接口
var baseURL = 'http://localhost:3008';
// 创建ajax对象
var xhr = new XMLHttpRequest();
xhr.open('GET', baseURL + '/api/student/getStudent');
// send发送 GET发送null就行
xhr.send(null);
// 监听状态的变化，过程是异步的
xhr.onreadystatechange = function() {
    if (xhr.readyState == a && xhr.status == 200) {
        var studentDate = JSON.parse(xhr.responseText); //获取后台的数据(现在是一个数组里，有全部对象数据)
        var relDateHtml = ''; //新建一个空字符串
        for (var i = 0; i < studentDate.length; i++) {
            // 把对象里的数据拼接到空字符串中
            relDataHtml += `<tr>
              <td>${studentData[i].id}</td>
              <td>${studentData[i].clazz}</td>
              <td>${studentData[i].name}</td>
              <td>${studentData[i].gender}</td>
              <td>${studentData[i].age}</td>
              <td>${studentData[i].tel}</td>
              <td>${studentData[i].hobby}</td>
              <td>${studentData[i].address}</td>
              <td>${studentData[i].remark}</td>
              <td>${studentData[i].date}</td>
              <td><a href="#" class="update_btn">修改</a><a href="#" class="delete_btn">删除</a></td></tr>`
        };
        //如果没有数据，就输入未找到数据
        if (!relDataHtml) {
            relDataHtml = `<tr><td colspan="11">没有查询到数据</td></tr>`
        };
        // 如果有直接把上边的字符串放在表格的tbody里边
        stuBody.innerHTML = relDataHtml;
    }
};
//搜索功能
var searchValue = document.querySelector('#searchvalue');
var searchBtn = document.querySelector('#search_btn');
// 给搜索功能添加点击事件
searchBtn.onclick = function() {
    // 去掉搜索值的前后空白
    var stuValue = searchValue.value.trim();
    var xhr = new XMLHttpRequest();
    xhr.open('GET', baseURL + '/api/student/getStudent' + '?name=' + stuValue);
    xhr.send(null);
    // 监听http状态的变化(异步方法)// 监听http状态的变化(异步方法)
    xhr.onreadystatechange = function() {
        // 根据状态的变化来获取数据
        if (xhr.readyState == 4 && xhr.status == 200) {
            // 获取后台传回的数据
            var studentData = JSON.parse(xhr.responseText);
            // 设置到页面上的数据
            var relDataHtml = '';
            for (var i = 0; i < studentData.length; i++) {
                // 拼接好的内容
                relDataHtml += `<tr>
            <td>${studentData[i].id}</td>
            <td>${studentData[i].clazz}</td>
            <td>${studentData[i].name}</td>
            <td>${studentData[i].gender}</td>
            <td>${studentData[i].age}</td>
            <td>${studentData[i].tel}</td>
            <td>${studentData[i].hobby}</td>
            <td>${studentData[i].address}</td>
            <td>${studentData[i].remark}</td>
            <td>${studentData[i].date}</td>
            <td><a href="#" class="update_btn">修改</a><a href="#" class="delete_btn">删除</a></td></tr>`
            };
            // 当没有数据时,添加到页面
            if (!relDataHtml) {
                relDataHtml = `<tr><td colspan="11">没有查询到数据</td></tr>`
            };
            stuBody.innerHTML = relDataHtml;
        }
    }
}