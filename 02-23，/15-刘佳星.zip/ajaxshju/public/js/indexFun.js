// 获取元素
var stuBody = document.querySelector('#tbody_stu');
// |服务器地址
var baseURL = 'http://localhost:3008';
// 发送请求得到后台数据
getData(baseURL + '/api/student/getStudent', '', showPage);
//拼tr td  封装的函数
function showPage(xhrObj) {
    console.log(0);
    var studentData = JSON.parse(xhrObj.responseText);
    var relDataHtml = ''; //新建一个空字符串
    for (var i = 0; i < studentData.length; i++) {
        // 拼接好的内容
        relDataHtml += `<tr>
     <td>${studentData[i]._id}</td>
     <td>${studentData[i].clazz}</td>
     <td>${studentData[i].name}</td>
     <td>${studentData[i].gender}</td>
     <td>${studentData[i].age}</td>
     <td>${studentData[i].tel}</td>
     <td>${studentData[i].hobby}</td>
     <td>${studentData[i].address}</td>
     <td>${studentData[i].remark}</td>
     <td>${studentData[i].date}</td>
     <td><a href="./page/update.html?id=${studentData[i]._id}" class="update_btn" data-stud-id="${studentData[i]._id}">修改</a><a href="JavasCRipt:void(0)" class="delete_btn" id="${studentData[i]._id}">删除</a></td></tr>`
    };
    //如果没有数据，就输入未找到数据
    if (!relDataHtml) {
        relDataHtml = `<tr><td colspan="11">没有查询到数据</td></tr>`
    };
    // 如果有直接把上边的字符串放在表格的tbody里边
    stuBody.innerHTML = relDataHtml;
    // 为删除元素和修改元素添加事件
    addEvent();
};

function addEvent() {
    var deleteBtn = document.querySelectorAll('.delete_btn');
    for (var i = 0; i < deleteBtn.length; i++) {
        deleteBtn[i].onclick = function (e) {
            var flag = confirm('你确定不要我了吗'); //确认弹窗 点确认是true 取消是false
            if (flag) {
                alert('删除了');
                getData(baseURL + '/api/student/removeStudent', { id: this.id }, function () { //调用删除接口，删除后台数据
                    // 删除结点
                    e.target.parentNode.parentNode.remove(); //this 的父元素的父元素，找到直接删除
                });
                // a标签:默认跳转,会刷新页面
                // #:阻止跳转,不会刷新页面但是会跳转到本页面的顶部
                // 阻止默认事件--解决a标签跳转到顶部或者刷新页面
                // e.preventDefault();
                // href="JavasCRipt:void(0)" 把a标签的跳转路径改为这个可以防止页面刷新和跳转到顶部
            }
        }
    }
    //获取所有修改按钮
    var updateBtn = document.querySelectorAll('.update_btn');
    // 用for循环 来绑定时间
    for (var k = 0; k < updateBtn.length; k++) {
        updateBtn[k].onclick = function () {
            localStorage.setItem('stuId', this.dataset.studId); //data-stud-id这个是自定义的id名字  使用this.dataset.studId可以使用
        }
    }
};
//搜索功能
var searchValue = document.querySelector('#searchvalue');
var searchBtn = document.querySelector('#search_btn');
// 绑定搜索事件
searchBtn.onclick = function () {
    // 清除搜索值得前后空白
    var stuValue = searchValue.value.trim();
    getData(baseURL + '/api/student/getStudent', { name: stuValue }, showPage);
}