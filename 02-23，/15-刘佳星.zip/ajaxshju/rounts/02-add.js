let express = require('express');
let app = express();
let cors = require('cors')
app.use(cors());
// 引入数据库代码
require('../db/01-链接数据库')
let makeData = require('../db/02-获取数据')

let bodyParser = require('body-parser');
app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// 获取数据

// 更新数据
function upda(uda){
    makeData.find().then(data=>{
        uda.send(data)
    })
}

app.get('/api/student/getStudent', (req, res) => {
    makeData.find().then(data => {
        res.send(200, data)
    })
})

// 添加数据
app.post('/api/student/addStudent', (req, res) => {
    console.log(req.body);
    makeData.create(req.body).then(data => {
        upda(res)
    })

})
// 删除数据
app.get('/api/student/removeStudent', (req, res) => {
    makeData.deleteOne({_id:req.query.id}).then(data => {
        // console.log(req.query);
        // console.log({_id:req.query.id});
        upda(res)
    })
})
// 修改数据
app.post('/api/student/updateStudent', (req, res) => {
    console.log(req.body.id);
    makeData.updateOne({_id:req.body.id},req.body).then(data => {
        console.log(req.body.id);
        res.send(data)
    })
})
app.listen(3008, () => {
    console.log('3008');
})