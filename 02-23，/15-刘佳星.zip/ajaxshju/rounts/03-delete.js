let express = require('express');
let app = express();
let cors = require('cors')
app.use(cors());
// 引入数据库代码
require('../db/01-链接数据库')
let makeData = require('../db/02-获取数据')

app.get('/api/student/updateStudent', (req, res) => {

    makeData.deleteOne({
        uname: req.body
    }).then((result) => {
        console.log(result);
    });
    makeData.find().then(data => {
        res.send(200, data)
    })
})
app.listen(3008, () => {
    console.log('3008');
})