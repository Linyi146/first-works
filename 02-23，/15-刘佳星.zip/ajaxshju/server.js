let express=require('express');
let app=express();
require('./db/01-链接数据库')
let makeData= require('./db/02-获取数据')
let cors=require('cors');
let bodyParser=require('body-parser');
app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());
app.use(cors())
app.listen(3008,()=>{
    console.log(3008);
})