const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser')

// 解决跨域
app.use(cors());
// 设置post请求格式
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
    // 引入连接数据库的代码
require('./db/db.js');
let user = require('./db/userschma');
// get请求
//获取数据
app.get('/api/student/getStudent', (req, res) => {
    console.log(req.query);
    if (req.query.name) {
        user.find({ name: req.query.name }).then((data) => {
            console.log(data);
            res.status(200).send(data);
        });
    } else if (req.query.id) {
        user.find({ _id: req.query.id }).then((data) => {
            res.status(200).send(data);
        });
    } else {
        user.find().then((data) => {
            res.status(200).send(data);
            // console.log(data);
        });
    }
});
//添加数据
app.post('/api/student/addStudent', (req, res) => {
    // let id = new Date().getTime();
    // req.body.id = id;
    user.create(req.body).then((rel) => {
        console.log(rel);
        console.log(req.body);
        res.status(200).send(req.body);
    }, () => {
        res.status(500).send('失败');
    });
});

// 删除数据
app.get('/api/student/removeStudent', (req, res) => {
    user.deleteOne({ "_id": req.query.id }).then(() => {
        res.status(200).send();
    });
});

// 修改数据
app.post('/api/student/updateStudent', (req, res) => {
    console.log(req.body);
    user.updateOne({ _id: req.body.id }, req.body).then((data) => {
        console.log(data);
        res.status(200).send(data);
    }, (err) => {
        console.log(err);
    });
});
//监听端口
app.listen(3008, () => {
    console.log('3008端口开启');
})