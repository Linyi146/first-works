// 服务器接口的地址
var baseURL = 'http://localhost:3008';
// 获取form元素
var addForm = document.querySelector('#add_form');
// 获取页面上的元素
var studInfo = document.querySelectorAll('.stud_info');
// 获取所有的性别元素
var gender = document.querySelectorAll('.gender');
// 获取所有的爱好的元素
var hobbies = document.querySelectorAll('.hobby');
// 学生的总数据
var allStudInfo = {};
addForm.onsubmit = function(e) {
    // 页面上可以通过value值直接得到的数据
    for (var i = 0; i < studInfo.length; i++) {
        allStudInfo[studInfo[i].name] = studInfo[i].value;
    };
    // 性别的信息的获取
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].checked) {
            allStudInfo.gender = gender[j].value;
            break;
        };
    };
    // 所有的爱好的信息获取
    var tempHobby = [];
    for (var k = 0; k < hobbies.length; k++) {
        if (hobbies[k].checked) {
            tempHobby.push(hobbies[k].value);
        }
    };
    allStudInfo.hobby = tempHobby.join();
    // 发送post请求，添加数据
    console.log(allStudInfo);
    postData(baseURL + '/api/student/addStudent', allStudInfo, function() {
        // 包含页面来源的域名
        console.log(location.origin);
        console.log(location.host);
        console.log(location.pathname);
        // 添加后,跳转到源网页
        location.href = location.origin + '/index.html';
    });
    // 阻止默认行为,提交表单,并刷新页面
    e.preventDefault();
}