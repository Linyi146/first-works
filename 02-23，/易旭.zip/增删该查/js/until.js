// get请求
function getData(url, data, fun) {
    // 创建对象
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url + dataFormatObj(data));
    // 发送
    xhr.send();
    // 监听状态的变化
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        };
    };
};


// 将对象转化为窗体格式


function dataFormatObj(obj) {
    if (!obj) {
        return '';
    };
    var arrtemp = [];
    // 遍历对象for...in
    for (var key in obj) {
        var value = obj[key].toString();
        arrtemp.push(key + '=' + value);
    };

    return '?' + arrtemp.join('&');
};


// post请求
function postData(url, data, fun) {
    // 创建对象
    var xhr = new XMLHttpRequest();
    // 注意转换为post的时候url直接是接口地址
    xhr.open('POST', url);
    // 设置请求头
    xhr.setRequestHeader('Content-Type', 'application/json');
    var dataJson = JSON.stringify(data);
    // 发送
    xhr.send(dataJson);
    // 监听状态的变化
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        };
    };
};