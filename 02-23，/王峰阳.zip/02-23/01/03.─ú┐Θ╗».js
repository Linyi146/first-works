// 路由分配
const express = require('express');
const app = express();
app.use('/admin', require('./routes/admin'));
app.listen(3000, () => {
    console.log('3000服务成功');
})