const express = require('express');
const app = express();
const home = require('./routes/home');
app.get('/', (req, res) => {
    res.send('/home')
});
app.use('/home', home);
app.listen(3000, () => {
    console.log("3000服务到了");
})