// nodejs 总结
// 应用的中间件  use  next set --验证拦截
//路由中间件  --是分发路由用的
//内置 中间件 静态托管的资源 express.static()
//第三方中间件：body-parser(post请求用的)，cors(跨域用的)，md5，ejs等等

// 最近学习的模块
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');
// 静态托管
// app.use(express.static('public'));
app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());
app.use('/api/student', require('./routes/students'));

// 监听端口
app.listen(3008, () => {
    console.log('3008端口开启');
});