var express = require('express');
var router = express.Router();
require('../db/db');
let userschma = require('../db/userschma');
router.get('/getStudent', (req, res) => {
    userschma.find().then(data => res.status(200).send(data))
});
module.exports = router;