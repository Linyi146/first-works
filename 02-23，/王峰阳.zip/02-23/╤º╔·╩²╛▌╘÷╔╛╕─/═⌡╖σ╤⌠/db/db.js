const mongoose = require('mongoose');
// 链接数据库
const DB = new mongoose.connect('mongodb://localhost/student', { useNewUrlParser: true, useUnifiedTopology: true });

// 链接数据库状态回调
DB.then(() => {
    console.log('数据库链接成功');
}, () => {
    console.log('数据库链接失败');
});