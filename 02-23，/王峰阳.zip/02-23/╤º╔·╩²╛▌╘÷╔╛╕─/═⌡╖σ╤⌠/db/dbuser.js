const mongoose = require('mongoose');

// 数据库集合规则
const schmea = new mongoose.Schema({
    id: String,
    clazz: String,
    name: String,
    age: Number,
    tel: Number,
    address: String,
    remark: String,
    date: String,
    gender: String,
    hobby: String,
});

// 创建表名
const User = mongoose.model('users', schmea);

// 暴露
module.exports = User;