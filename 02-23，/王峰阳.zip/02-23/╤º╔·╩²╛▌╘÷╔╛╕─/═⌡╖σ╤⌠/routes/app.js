const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const router = express.Router();

// 链接数据库
require('../db/db.js');
let User = require('../db/dbuser.js');

// 更新数据
function ajax(ajaxs) {
    User.find().then((data) => {
        ajaxs.send(200, data);
    });
};

// 查询数据
router.get('/getStudent', (req, res) => {
    User.find(req.query).then((data) => {
        res.send(200, data);
        // console.log(data);
    });
});

// 添加数据
router.post('/addStudent', (req, res) => {
    // 将时间戳作为id
    req.body.id = Date.now().toString();

    // 设置学生的创建时间
    if (!req.body.date) {
        req.body.date = new Date().toLocaleDateString();
        req.body.date = req.body.date.replace(/\//g, '-');
    };

    // 添加到数据库
    User.create(req.body).then((rel) => {
        console.log(rel);
        ajax(res);
        // res.send(200, '添加成功');
    });
});

// 删除数据
router.get('/removeStudent', (req, res) => {
    User.deleteOne(req.query).then((rel) => {
        console.log(rel);
        ajax(res);
    });
});

// 修改数据
router.post('/updateStudent', (req, res) => {
    User.updateOne({
        id: req.body.id
    }, req.body).then((rel) => {
        console.log(rel);
        ajax(res);
        // res.send(200, '修改成功');
    });
});



// 暴露
module.exports = router;