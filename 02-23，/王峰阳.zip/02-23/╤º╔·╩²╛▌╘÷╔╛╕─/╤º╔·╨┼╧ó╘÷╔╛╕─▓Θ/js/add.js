////添加数据的js
// 接口的地址
var baseURL = 'http://localhost:3008';
var addForm = document.querySelector('#add_form');
// 获取页面上的能直接用value使用的元素
var studInfo = document.querySelectorAll('.stud_info');
// 获取性别元素
var gender = document.querySelectorAll('.gender');
// 获取爱好的元素
var hobbies = document.querySelectorAll('.hobby');
var allStudInfo = {}; //新建一个对象，把新页面获取的数据添加进去，
// 为form表单添加提交事件
addForm.onsubmit = function(e) {
    for (var i = 0; i < studInfo.length; i++) {
        allStudInfo[studInfo[i].name] = studInfo[i].value; //用循环，把从页面上得到的所有值放入创建的对象里
    };
    // 性别的获取
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].checked) {
            allStudInfo.gender = gender[j].value; //效果和上边一样
            break; //因为是单选，所以得到值后，可以直接结束
        };
    };
    // 爱好的获取
    var tempHobby = []; //新建一个空数组，存放被选中的爱好
    for (var k = 0; k < hobbies.length; k++) {
        //hobbies[k].checked  这个意思是，选项被选中
        if (hobbies[k].checked) {
            tempHobby.push(hobbies[k].value); //效果同上
        }
    };
    allStudInfo.hobby = tempHobby.join(); //因为是多选，所以把得到的值转化为串
    postData(baseURL + '/api/student/addStudent', allStudInfo, function() { //allStudInfo 这个是上边创建的数组，转化为了字符串
        // 添加后,跳转到源网页
        location.href = '../index.html';
    });
    // 阻止默认行为,提交表单,并刷新页面
    e.preventDefault();
}