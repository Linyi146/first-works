//GET请求 封装的函数
function getData(url, data, fun) { //url是调用接口的路径  data 是传入的对象  fun 是你需要操作的函数
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url + dataFormatObj(data));
    xhr.send(null);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr); //xhr 是请求后得到的后台数据 以实参传入函数进行操作
        };
    }
}
// post请求 封装的函数
function postData(url, data, fun) {
    var xhr = new XMLHttpRequest();
    // 注意转换为post的时候url直接是接口地址
    xhr.open('POST', url);
    // 设置请求头
    xhr.setRequestHeader('Content-Type', 'application/json');
    var dataJson = JSON.stringify(data);
    // POST  发送的是你需要发送给后台的对象数据
    xhr.send(dataJson);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        };
    };
};
// 把data的对象数据改变为字符串  封装的函数
function dataFormatObj(obj) {
    if (!obj) {
        return '';
    };
    var arrtemp = [];
    // 遍历对象for...in
    for (var key in obj) {
        var value = obj[key].toString();
        arrtemp.push(key + '=' + value);
    };

    return '?' + arrtemp.join('&');
};