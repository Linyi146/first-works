//修改数据的js
// 接口的地址
var baseURL = 'http://localhost:3008';
var updateForm = document.querySelector('#update_form');
// 获取页面上的可以用value操作元素
var studInfo = document.querySelectorAll('.stud_info');
// 获取性别元素
var gender = document.querySelectorAll('.gender');
// 获取爱好的元素
var hobbies = document.querySelectorAll('.hobby');
// 从页面的url中取出id值,获取学生的数据为 ?id=999999 然后用等号切割后是数组，选择第二个是id值
var studUpdateId = location.search.split('=')[1];

// 通过以上操作获取数据，在下边把数据值添加到页面上
getData(baseURL + '/api/student/getStudent', { id: studUpdateId }, function(xhr) {
    // 获取所有的数据设置到页面上
    var studUpdateObj = JSON.parse(xhr.responseText)[0];
    for (var i = 0; i < studInfo.length; i++) {
        console.log(studUpdateObj[studInfo[i].name]);
        studInfo[i].value = studUpdateObj[studInfo[i].name]; //把点击的后台数据添加到页面上
    };
    // 性别的信息的设置
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].value == studUpdateObj.gender) {
            gender[j].checked = true; //后台数据有值，就把属性改为true，是选中的意思
        };
    };
    // 爱好的设置
    for (var k = 0; k < hobbies.length; k++) {
        if (studUpdateObj.hobby.includes(hobbies[k].value)) {
            hobbies[k].checked = true; //和性别一样
        };
    };
});
//修改后，保存到后台的新数据
// 学生的总数据
var allStudInfo = {};
updateForm.onsubmit = function(e) {
    // 页面上可以通过value值直接得到的数据
    for (var i = 0; i < studInfo.length; i++) {
        allStudInfo[studInfo[i].name] = studInfo[i].value;
    };
    // 性别的信息的获取
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].checked) {
            allStudInfo.gender = gender[j].value;
            break;
        };
    };
    // 所有的爱好的信息获取
    var tempHobby = [];
    for (var k = 0; k < hobbies.length; k++) {
        if (hobbies[k].checked) {
            tempHobby.push(hobbies[k].value);
        }
    };
    allStudInfo.hobby = tempHobby.join();
    // 设置学生数据对象的id值
    allStudInfo.id = studUpdateId;
    // 发送post请求，添加数据
    console.log(allStudInfo);
    postData(baseURL + '/api/student/updateStudent', allStudInfo, function() {
        // 包含页面来源的域名
        location.href = '../index.html';
    });
    // 阻止默认行为,提交表单,并刷新页面
    e.preventDefault();
}