// 1.引入mongoose模块
const mongoose = require('mongoose');
// 创建集合规则
const userSchema = new mongoose.Schema({
    uname: String,
    age: Number,
    tel: Number,
    id: Number,
    clazz: String,
    hobby: String,
    address: String,
    remark: String,
    gender: String,
    date: Date
})

// 利用规则创建集合
const User = mongoose.model('User', userSchema);
// 暴露出去.使用User
module.exports = User;