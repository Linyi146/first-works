const express = require('express');
const User = require('../db/userschma.js');
const router = express.Router();
require('../db/db.js');
const user = require('../db/userschma.js');
// 得到数据
router.get('/getStudent', (req, res) => {
    // console.log(req.query);
    if (req.query.name) {
        User.find({ uname: req.query.name }).then((data) => {
            res.status(200).send(data);
        });
    } else if (req.query.id) {
        User.find({ _id: req.query.id }).then((data) => {
            res.status(200).send(data);
        });
    } else {
        user.find().then((data) => {
            res.status(200).send(data);
        });
    };

});
// 添加数据
router.post('/addStudent', (req, res) => {
    // 将时间戳作为事件的id
    let id = new Date().getT;
    // 把id设置给数据
    req.body.id = id;
    user.create(req.body).then((data) => {
        res.status(200).send(req.body);
        console.log(req.body);
    }, () => {
        res.status(500).send('请求失败')
    });
});
// 删除数据
router.get('/removeStudent', (req, res) => {
    if (req.query.id) {
        User.deleteOne({ _id: req.query.id }).then((rel) => {
            res.status(200).send('删除成功');
        })
    } else {
        res.status(500).send('id不能为空')
    }
});
// 更新数据
router.post('/updateStudent', (req, res) => {
    console.log(req.body._id);
    User.updateOne({ _id: req.body._id }, req.body).then((date) => {
        console.log(req.body);
        console.log(date);
        res.status(200).send(date);
    });
});
module.exports = router;