// 获取元素
var stuBody = document.querySelector('#tbody_stu');
// 服务器接口的地址
var baseURL = 'http://localhost:3008';

// 发送请求得到所有的数据
getData(baseURL + '/api/student/getStudent', '', showPage);

function showPage(xhrObj) {
    // 获取后台传回的数据
    var studentData = JSON.parse(xhrObj.responseText);
    // 设置到页面上的数据
    var relDataHtml = '';
    for (var i = 0; i < studentData.length; i++) {
        // 拼接好的内容
        relDataHtml += `<tr>
     <td>${studentData[i]._id}</td>
     <td>${studentData[i].clazz}</td>
     <td>${studentData[i].uname}</td>
     <td>${studentData[i].gender}</td>
     <td>${studentData[i].age}</td>
     <td>${studentData[i].tel}</td>
     <td>${studentData[i].hobby}</td>
     <td>${studentData[i].address}</td>
     <td>${studentData[i].remark}</td>
     <td>${studentData[i].date}</td>
     <td><a href="./page/update.html?id=${studentData[i]._id}" class="update_btn" data-stud-id="${studentData[i]._id}">修改</a><a href="javascript:void(0)" class="delete_btn" id="${studentData[i]._id}">删除</a></td></tr>`
    };
    // 当没有数据时,添加到页面
    if (!relDataHtml) {
        relDataHtml = `<tr><td colspan="11">没有查询到数据</td></tr>`
    };
    stuBody.innerHTML = relDataHtml;
    // 为删除元素和修改元素添加事件
    addEvent();
};

function addEvent() {
    // 获取所有的删除按钮
    var deleteBtn = document.querySelectorAll('.delete_btn');
    for (var i = 0; i < deleteBtn.length; i++) {
        deleteBtn[i].onclick = function(e) {
            // true或者false
            var flag = confirm('您确定要删除吗?');
            if (flag) {
                console.log('删除了');
                // 删除数据库的内容
                getData(baseURL + '/api/student/removeStudent', { id: this.id }, function() {
                    // 删除结点
                    // 事件对象
                    console.log(e);
                    //e.target当前触发事件的事件源
                    console.log(e.target);
                    e.target.parentNode.parentNode.remove();
                });
                // a标签:默认跳转,会刷新页面
                // #:阻止跳转,不会刷新页面但是会跳转到本页面的顶部
                // 阻止默认事件--解决a标签跳转到顶部或者刷新页面
                // e.preventDefault();
            };
        }
    };
    // 修改按钮的绑定事件---还没有做
    // 获取所有的修改按钮
    var updateBtn = document.querySelectorAll('.update_btn');
    for (var k = 0; k < updateBtn.length; k++) {
        // 绑定事件
        updateBtn[k].onclick = function() {
            console.log(this);
            console.log(this.dataset);
            console.log(this.dataset.studId);
            localStorage.setItem('stuId', this.dataset.studId);
        };
    };
};

// 搜索
// 搜索功能
var searchValue = document.querySelector('#searchvalue');
var searchBtn = document.querySelector('#search_btn');
// 绑定搜索事件
searchBtn.onclick = function() {
    // 搜索的值的格式验证
    var stuValue = searchValue.value.trim();
    getData(baseURL + '/api/student/getStudent', { name: stuValue }, showPage);
}