var baseUrl = "http://localhost:3008";
var addForm = document.querySelector('#add_form');
var studInfo = document.querySelectorAll('.stud_info');
var gender = document.querySelectorAll('.gender');
var hobbies = document.querySelectorAll('.hobby')
console.log(gender);
console.log(hobbies);

var allStuInfo = {};

addForm.onsubmit = function(e) {
    console.log(99);
    for (var i = 0; i < studInfo.length; i++) {
        // console.log([studInfo[i].name], studInfo[i].value);
        allStuInfo[studInfo[i].name] = studInfo[i].value;
    }
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].checked) {
            allStuInfo.gender = gender[j].value;
            break;
        }
    }
    var tempHobby = [];
    for (var k = 0; k < hobbies.length; k++) {
        if (hobbies[k].checked) {
            tempHobby.push(hobbies[k].value);
        };
    }
    allStuInfo.hobby = tempHobby.join();
    console.log(allStuInfo);
    postData('http://localhost:3008/api/student/addStudent', allStuInfo, function() {
        location.href = location.origin + '/page/index.html';
        console.log(location.origin);
        // http://localhost:3008

    })
    e.preventDefault()
}