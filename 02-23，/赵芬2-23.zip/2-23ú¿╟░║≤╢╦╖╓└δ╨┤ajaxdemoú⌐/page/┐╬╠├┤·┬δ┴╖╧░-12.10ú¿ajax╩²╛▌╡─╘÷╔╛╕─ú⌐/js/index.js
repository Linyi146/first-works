var baseUrl = "http://localhost:3008";
// 页面呈现数据
var tBody = document.querySelector('tbody');
getData(baseUrl + "/api/student/getStudent", "", showPage);
// 数据拼接
function showPage(xhr) {
    var studentData = JSON.parse(xhr.responseText);
    var relData = '';
    for (var i = 0; i < studentData.length; i++) {
        relData += ` <tr>
        <td>${studentData[i].id}</td>
        <td>${studentData[i].clazz}</td>
        <td>${studentData[i].name}</td>
        <td>${studentData[i].gender}</td>
        <td>${studentData[i].age}</td>
        <td>${studentData[i].tel}</td>
        <td>${studentData[i].hobby}</td>
        <td>${studentData[i].address}</td>
        <td>${studentData[i].remark}</td>
        <td>${studentData[i].date}</td>
        <td><a href="update.html?id=${studentData[i].id}" class="update-btn" data-stud-id="${studentData[i].id}">修改</a> <a href="#" class="rel-btn" id="${studentData[i].id}">删除</a></td>
    </tr>`
    }
    if (!relData) {
        relData = `<tr><td>没有获取到数据</td></tr>`
    }
    tBody.innerHTML = relData;
    addEvent();
}
// 搜索
var searchValue = document.querySelector('.search');
var searBtn = document.querySelector('.search-btn');

searBtn.onclick = function() {
        var sValue = searchValue.value.trim();
        getData(baseUrl + '/api/student/getStudent', { name: sValue }, showPage);
    }
    // 删除
function addEvent() {
    var delBtn = document.querySelectorAll('.rel-btn');
    console.log(delBtn);
    for (var i = 0; i < delBtn.length; i++) {
        delBtn[i].onclick = function(e) {
            // var studentId = this.parentNode.parentNode.children[0].innerText;
            var flag = confirm('确认删除');
            if (flag) {
                getData(baseUrl + "/api/student/removeStudent", { id: this.id }, function() {
                    console.log(e.target);
                    e.target.parentNode.parentNode.remove();
                });
            };
        };
    };

    // 修改
    var updateBtn = document.querySelectorAll('.update-btn');
    for (var i = 0; i < updateBtn.length; i++) {
        updateBtn[i].onclick = function() {
            localStorage.setItem("stuId", this.dataset.studId);
        };
    };
};