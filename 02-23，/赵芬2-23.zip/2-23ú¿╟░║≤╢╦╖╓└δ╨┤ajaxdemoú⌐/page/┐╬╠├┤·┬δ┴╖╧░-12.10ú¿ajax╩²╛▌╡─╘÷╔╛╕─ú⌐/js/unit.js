function getData(url, data, fun) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "?" + tempData(data));
    xhr.send(null);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        }
    }
}

function tempData(obj) {
    if (!obj) {
        return "";
    } else {
        var tempArr = [];
        for (var key in obj) {
            var value = obj[key].toString();
            tempArr.push(key + "=" + value)
        };
        return tempArr.join('&');
    }
}

function postData(url, data, fun) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(data));
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        }
    }
}