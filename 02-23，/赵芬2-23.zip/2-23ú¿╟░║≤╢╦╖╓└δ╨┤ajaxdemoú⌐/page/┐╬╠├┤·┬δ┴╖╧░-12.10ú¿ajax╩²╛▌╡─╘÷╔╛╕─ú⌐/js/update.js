var baseUrl = "http://localhost:3008";
var updateForm = document.querySelector('#update_form');
var studInfo = document.querySelectorAll('.stud_info');
var gender = document.querySelectorAll('.gender');
var hobbies = document.querySelectorAll('.hobby');

var studUpdateId = location.search.split("=")[1]; //获取需要修改的学生的id值
console.log(studUpdateId);
//把需要修改的那个学生的信息放在修改页面的响应的位置
getData(baseUrl + "/api/student/getStudent", { id: studUpdateId }, function(xhr) {
    var studUpdateObj = JSON.parse(xhr.responseText)[0]; //xhr.responseText是一个数组对象

    for (var i = 0; i < studInfo.length; i++) {
        studInfo[i].value = studUpdateObj[studInfo[i].name];
        console.log(studInfo[i].value);
    };
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].value = studUpdateObj.gender) {
            gender[j].checked = true;
        };
    };
    for (var k = 0; k < hobbies.length; k++) {
        if (studUpdateObj.hobby.includes(hobbies[k].value)) {
            hobbies[k].checked = true;
        };
    };
});



var allStudInfo = {};
updateForm.onsubmit = function(e) {
    for (var i = 0; i < studInfo.length; i++) {
        allStudInfo[studInfo[i].name] = studInfo[i].value;
    }
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].checked) {
            allStudInfo.gender = gender[j].value;
            break;
        }
    }
    var tempHobby = [];
    for (var k = 0; k < hobbies.length; k++) {
        if (hobbies[k].checked) {
            tempHobby.push(hobbies[k].value);
        }
    }
    allStudInfo.hobby = tempHobby.join();
    allStudInfo.id = studUpdateId;
    postData(baseUrl + "/api/student/updateStudent", allStudInfo, function() {
        location.href = location.origin + "/page/index.html";
    });
    e.preventDefault();
}