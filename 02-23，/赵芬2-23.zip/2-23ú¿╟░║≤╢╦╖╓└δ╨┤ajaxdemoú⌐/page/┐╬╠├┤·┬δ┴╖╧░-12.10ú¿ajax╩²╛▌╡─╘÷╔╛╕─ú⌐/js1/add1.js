var baseUrl = "http://localhost:3008";
var addForm = document.querySelector('#add_form');
console.log(addForm);
var studInfo = document.querySelectorAll('.stud_info');
var gender = document.querySelectorAll('.gender');
var hobbies = document.querySelectorAll('.hobby');

// 添加
// 给表单绑定提交事件
var allStudObj = {};
addForm.onsubmit = function(e) {
    for (var i = 0; i < studInfo.length; i++) {
        allStudObj[studInfo[i].name] = studInfo[i].value;
    }
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].checked) {
            allStudObj.gender = gender[j].value;
        }
    }
    var tempArr = [];
    for (var k = 0; k < hobbies.length; k++) {
        if (hobbies[k].checked) {
            tempArr.push(hobbies[k].value);
        }
    }
    allStudObj.hobby = tempArr.join();
    postData(baseUrl + "/api/student/addStudent", allStudObj, function() {
        location.href = location.origin + "/page1/index1.html";
    });
    e.preventDefault();
}