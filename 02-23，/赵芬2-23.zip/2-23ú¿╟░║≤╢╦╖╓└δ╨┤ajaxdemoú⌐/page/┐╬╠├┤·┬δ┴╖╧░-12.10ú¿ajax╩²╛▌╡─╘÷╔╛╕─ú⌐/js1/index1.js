var baseUrl = "http://localhost:3008";
// 页面得到数据
var tBody = document.querySelector('tbody');
getData(baseUrl + "/api/student/getStudent", "", showPage);

// 字符串拼接
function showPage(xhr) {
    // 从数据库得到学生的所有数据
    var stuDate = JSON.parse(xhr.responseText);
    console.log(stuDate);
    var relData = '';
    for (var i = 0; i < stuDate.length; i++) {
        relData += ` <tr>
        <td>${stuDate[i].id}</td>
        <td>${stuDate[i].clazz}</td>
        <td>${stuDate[i].name}</td>
        <td>${stuDate[i].gender}</td>
        <td>${stuDate[i].age}</td>
        <td>${stuDate[i].tel}</td>
        <td>${stuDate[i].hobby}</td>
        <td>${stuDate[i].address}</td>
        <td>${stuDate[i].remark}</td>
        <td>${stuDate[i].date}</td>
        <td><a href="update1.html?id=${stuDate[i].id}" class="update_btn" data-stud-id="${stuDate[i].id}">修改</a> <a href="#" class="del_btn" id="${stuDate[i].id}">删除</a></td>
    </tr>`
    }
    if (!relData) {
        relData += `<tr><td>没有查询到数据</td></tr>`
    }
    tBody.innerHTML = relData;
    AddEvent();
}
// 数据的删除与修改
function AddEvent(e) {
    // var delBtn = document.getElementsByClassName("del_btn");
    var delBtn = document.querySelectorAll('.del_btn');
    console.log(delBtn);
    for (var i = 0; i < delBtn.length; i++) {
        delBtn[i].onclick = function(e) {
            var flag = confirm("确定删除吗？")
            if (flag) {
                getData(baseUrl + "/api/student/removeStudent", { id: this.id }, function() {
                    e.target.parentNode.parentNode.remove();
                });
                e.preventDefault();
            }
        }
    }

    // 修改
    var updateBtn = document.querySelectorAll('.update_btn');
    console.log(updateBtn);
    console.log(11);
    for (var i = 0; i < updateBtn.length; i++) {
        updateBtn[i].onclick = function() {
            localStorage.setItem("stuId", this.dataset.studId)
        }
    }

}