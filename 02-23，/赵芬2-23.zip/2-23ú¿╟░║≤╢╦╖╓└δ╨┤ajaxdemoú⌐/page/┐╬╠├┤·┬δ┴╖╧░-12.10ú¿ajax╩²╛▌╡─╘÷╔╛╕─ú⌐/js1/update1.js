var baseUrl = "http://localhost:3008";
var updateForm = document.querySelector('#update_form');
var studInfo = document.querySelectorAll('.stud_info');
var gender = document.querySelectorAll('.gender');
var hobbies = document.querySelectorAll('.hobby');
// 把需要修改的数据的那一行显示下修改页面的响应位置
var studUpdateId = location.search.split('=')[1];
console.log(studUpdateId);
getData(baseUrl + "/api/student/getStudent", { id: studUpdateId }, function(xhr) {
    var studObj = JSON.parse(xhr.responseText)[0];
    for (var i = 0; i < studInfo.length; i++) {
        studInfo[i].value = studObj[studInfo[i].name];
    }
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].value = studObj.gender) {
            gender[j].checked = true;
            break;
        }
    }
    for (var k = 0; k < hobbies.length; k++) {
        if (studObj.hobby.includes(hobbies[k].value)) {
            hobbies[k].checked = true;
        }
    }
});
// 修改数据
var allStudData = {}; //创建数组，用该存储学生的总数据
updateForm.onsubmit = function(e) {
    for (var i = 0; i < studInfo.length; i++) {
        allStudData[studInfo[i].name] = studInfo[i].value;
    }
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].checked) {
            allStudData.gender = gender[j].value;
            break;
        }
    }
    var tempArr = [];
    for (var k = 0; k < hobbies.length; k++) {
        if (hobbies[k].checked) {
            tempArr.push(hobbies[k].value);
        }
    }
    allStudData.hobby = tempArr.join();
    allStudData.id = studUpdateId;
    postData(baseUrl + "/api/student/updateStudent", allStudData, function() {
        location.href = location.origin + "/page1/index1.html"
    })
    e.preventDefault();
}