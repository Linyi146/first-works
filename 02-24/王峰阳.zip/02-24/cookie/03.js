const express = require('express');
const cookieParser = require('cookie-parser');
const app = express();
app.use(cookieParser('8888kkkyyoo'));
app.get('/setCookie', (req, res) => {
    res.cookie("wwid", 'pp', {
        maxAge: 24 * 60 * 60 * 1000,
        signed: true
    });
    res.send('设置成功')
});
app.get('/getCookie', (req, res) => {
        console.log(req.cookies);
        console.log(req.signedCookies);
        res.send(req.signedCookies);
    })
    // 监听端口
app.listen(3000, () => {
    console.log('3000端口开启');
});