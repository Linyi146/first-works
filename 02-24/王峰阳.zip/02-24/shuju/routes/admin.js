const express = require('express');
const router = express.Router();
// 登录页面
router.get('/login', require('./admin-router/login.js'));
// 登录后
router.get('/productlist', require('./admin-router/productlist.js'));
// 增加
router.get('/productadd', require('./admin-router/productadd.js'));
// 修改
router.get('/productedit', require('./admin-router/productedit.js'));
module.exports = router;