// npm install express ejs body-parser cors mongoose --save
const express = require('express');
const app = express();
const ejs = require('ejs');
const bodyParser = require('body-parser');
const cors = require('cors');
// 设置静态资源,获取post的信息
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// 跨域
app.use(cors());
// 静态托管
app.use(express.static('public'));
// ejs的模板引擎
app.set('view engine', 'ejs');
// 配置路由信息
const admin = require('./routes/admin.js')
app.use('/admin', admin);
// 端口开启
app.listen(3000, () => {
    console.log('3000开启');
});