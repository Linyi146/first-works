const express = require('express');
const app = express();
// 引入cookie的第三方中间件
const cookieParser = require('cookie-parser');
// 设置cookie
app.use(cookieParser());
app.get('/setCookie', (req, res) => {
    res.cookie('pwid', '123', {
        // 设置cookie的过期时间，毫秒数
        maxAge: 24 * 60 * 60 * 1000,
        // signed: true
    });
    res.send('设置成功')
});
// 得到cookie
app.get('/getCookie', (req, res) => {
        // 得到cookie
        res.send(req.cookies);
        console.log(req.cookies);
    })
    // 监听端口
app.listen(3000, () => {
    console.log('3000开启');
})