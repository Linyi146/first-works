const express = require('express');
// 出书画web服务方法
const app = express();
// 引入第三方cookie的中间件
const cookieParser = require('cookie-parser');
// 使用use进行拦截使用cookie-parser
// 传递一个字符串，作为假币签名的密码
// 设置签名的字符串
app.use(cookieParser('6688'));
app.get('/setCookie', (req, res) => {
    // 设置cookie
    res.cookie('pwd66', '66666', {
        // 设置cookie的过期时间
        maxAge: 24 * 60 * 60 * 1000 * 3,
        // 设置允许使用signed
        signed: true
    });
    res.send('设置成功了')
});
// 得到cookie
app.get('/getCookie', (req, res) => {
        // 得到cookie
        // res.send(req.Cookies);
        // console.log(req.Cookies);
        res.send(req.signedCookies);
        console.log(req.signedCookies);
    })
    // 点听端口
app.listen(3000, () => {
    console.log('3000开启');
})