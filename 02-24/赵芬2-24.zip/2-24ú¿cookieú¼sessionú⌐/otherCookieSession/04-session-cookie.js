const express = require('express');
const app = express();
// npm install express-sission --save
const session = require('express-session');
app.use(session({
    secret: 'zz',
    name: 'ss',
    // 强制保存session： 默认true不保存， false保存
    resave: false,
    // 强制保存初始化session
    saveUninitialized: true,
    cookie: {
        // secure:true,//https协议
        maxAge: 10 * 1000
    },
    // 强制重置cookie过期时间
    rolling: true
}));
// 设置登录信息
app.get('/login', (req, res) => {
    req.session.uname = '张美丽';
    res.send('登录成功')
});
// 判断是否有登录信息存在
app.get('/mainpage', (req, res) => {
    console.log(req.session.uname);
    // 判定信息是否存在
    if (req.session.uname) {
        res.send('欢迎' + req.session.uname + '登录');
    } else {
        res.send('请重新登录')
    }
});
app.listen(3000, () => {
    console.log('3000开启');
})