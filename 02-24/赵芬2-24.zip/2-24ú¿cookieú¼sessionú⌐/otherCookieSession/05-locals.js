const express = require('express');
const app = express();
const ejs = require('ejs');
// 配置ejs模板引擎
app.set('view engine', 'ejs');
// 通过express的locals方法设置一个ejs中使用的公共数据
app.locals.user = {
    uname: '张美丽'
};
app.get('/main', (req, res) => {
    res.render('main');
})
app.get('/login', (req, res) => {
    res.render('login');
});
app.listen(3000, () => {
    console.log('3000开启');
})