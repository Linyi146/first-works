const express = require('express');
const { Cooie } = require('express-session');
const session = require('express-session');
const app = express();

app.use(session({
    secret: "linyi",
    name: 'aaaa', //这里不能是中文
    resave: false,
    saveUninitialized: true,
    cookie: {
        maxAge: 5 * 1000
    },
    rolling: true
}));
app.get('/login', (req, res) => {
    req.session.uname = "马冰玉";
    res.send('登录成功');
});
app.get('/mainpage', (req, res) => {
    console.log(req.session.uname);
    if (req.session.uname) {
        res.send('欢迎' + req.session.uname + '回家')
    } else {
        res.send('信息错误，请重新登录');
    }
});
app.listen(3000, () => {
    console.log('请稍等，3000端口加载中...');
})