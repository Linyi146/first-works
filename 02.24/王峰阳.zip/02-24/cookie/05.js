const express = require('express');
const app = express();
const ejs = require('ejs');

// 配置ejs模板
app.set("view engine", "ejs");
app.locals.user = {
    uname: "阳"
};
app.get('/index', (a, res) => {
    res.render('index');
});
app.get('/login', (a, res) => {
    res.render('login');
});
app.listen(3000)